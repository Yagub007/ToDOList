from django.shortcuts import render, redirect, get_object_or_404
from .models import Task
from .forms import TaskForm
from django.http import JsonResponse

from django.shortcuts import render, get_object_or_404
from .models import Task
COLORS = ['#CDA6FF', '#A4FE94', '#FFDBA1', '#CFFF47', '#F8B8F9', '#BEE8FF', '#FFA4A4']


def task_list(request, task_type=None):
    task_types = Task.objects.values_list('type', flat=True).distinct()

    if task_type:
        tasks = Task.objects.filter(type=task_type).order_by('deadline')
    else:
        tasks = Task.objects.all().order_by('deadline')

    return render(request, 'task_list.html', {
        'tasks': tasks,
        'task_types': task_types,
        'selected_type': task_type
    })
def task_create(request):
    if request.method == 'POST':
        form = TaskForm(request.POST)
        if form.is_valid():
            form.save()
            return redirect('task_list')
    else:
        form = TaskForm()
    return render(request, 'task_form.html', {'form': form})

def task_update(request, task_id):
    task = get_object_or_404(Task, id=task_id)
    if request.method == 'POST':
        form = TaskForm(request.POST, instance=task)
        if form.is_valid():
            form.save()
            return redirect('task_list')
    else:
        form = TaskForm(instance=task)
    return render(request, 'task_form.html', {'form': form})

def task_delete(request, task_id):
    task = get_object_or_404(Task, id=task_id)
    if request.method == 'POST':
        task_type = task.type
        task.delete()
        return JsonResponse({'success': True, 'task_type': task_type})
    return render(request, 'task_confirm_delete.html', {'task': task})

